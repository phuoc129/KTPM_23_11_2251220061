import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from utils.credentials import VALID_USERNAME, VALID_PASSWORD
from pages.login_page import LoginPage
@pytest.fixture
def driver():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("https://www.saucedemo.com/")
    yield driver
    driver.quit()

@pytest.fixture
def setup(driver):
    login_page = LoginPage(driver)
    login_page.login(VALID_USERNAME, VALID_PASSWORD)
    return driver