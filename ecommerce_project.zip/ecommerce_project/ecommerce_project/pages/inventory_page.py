from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage

class InventoryPage(BasePage):

    CART_BADGE = (By.CLASS_NAME, "shopping_cart_badge")

    def add_to_cart(self, product_name):
        locator = (By.ID, f"add-to-cart-{product_name}")
        self.click(locator)

    def remove_from_cart(self, product_id):
        btn = self.driver.find_element(By.ID, f"remove-{product_id}")
        btn.click()

        # Wait until cart badge updates (badge disappears)
        try:
            self.wait.until_not(EC.visibility_of_element_located(self.CART_BADGE))
        except TimeoutException:
            pass

    def cart_count(self):
        try:
            badge = self.driver.find_element(By.CLASS_NAME, "shopping_cart_badge")
            return int(badge.text)
        except:
            return 0


    SORT_DROPDOWN = (By.CLASS_NAME, "product_sort_container")
    ITEM_NAME = (By.CLASS_NAME, "inventory_item_name")
    ITEM_PRICE = (By.CLASS_NAME, "inventory_item_price")

    def select_sort(self, value):
        dropdown = self.find(self.SORT_DROPDOWN)
        dropdown.find_element(By.CSS_SELECTOR, f"option[value='{value}']").click()

    def get_product_names(self):
        items = self.find_elements(self.ITEM_NAME)
        return [item.text for item in items]

    def get_product_prices(self):
        items = self.find_elements(self.ITEM_PRICE)
        return [float(item.text.replace("$", "")) for item in items]
