from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class CartPage(BasePage):

    URL = "https://www.saucedemo.com/cart.html"   # FIX HERE!

    CART_ITEMS = (By.CLASS_NAME, "cart_item")
    CHECKOUT_BUTTON = (By.ID, "checkout")
    REMOVE_BUTTONS = (By.CLASS_NAME, "cart_button")

    def open(self):
        self.driver.get(self.URL)

    def get_items_count(self):
        return len(self.find_elements(self.CART_ITEMS))

    def click_checkout(self):
        self.find(self.CHECKOUT_BUTTON).click()

    def remove_first_product_cart(self):
        buttons = self.find_elements(self.REMOVE_BUTTONS)
        buttons[0].click()

    def remove(self, product_id):
        button = self.driver.find_element(By.ID, f"remove-{product_id}")
        button.click()


    