from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class CheckoutPage(BasePage):

    FIRST_NAME = (By.ID, "first-name")
    LAST_NAME = (By.ID, "last-name")
    ZIP = (By.ID, "postal-code")
    CONTINUE_BTN = (By.ID, "continue")
    FINISH_BTN = (By.ID, "finish")
    SUCCESS_MSG = (By.CLASS_NAME, "complete-header")
    ERROR_MSG = (By.CSS_SELECTOR, "h3[data-test='error']")

    def start_checkout(self):
        self.click((By.ID, "checkout"))

    def fill_info(self, fn, ln, zip_code):
        self.type(self.FIRST_NAME, fn)
        self.type(self.LAST_NAME, ln)
        self.type(self.ZIP, zip_code)
        self.click(self.CONTINUE_BTN)

    def finish(self):
        self.click(self.FINISH_BTN)

    def success_message(self):
        msg = self.driver.find_element(By.CLASS_NAME, "complete-header").text
        return msg.strip().upper()

    def get_error_message(self):
        return self.get_text(self.ERROR_MSG)
