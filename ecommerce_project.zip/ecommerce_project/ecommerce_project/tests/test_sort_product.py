from utils.credentials import VALID_USERNAME, VALID_PASSWORD
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
import pytest


@pytest.fixture
def setup(driver):
    login = LoginPage(driver)
    login.login(VALID_USERNAME, VALID_PASSWORD)
    return driver


def test_sort_name_az(setup):
    driver = setup
    inventory = InventoryPage(driver)

    inventory.select_sort("az")

    names = inventory.get_product_names()

    assert names == sorted(names)


def test_sort_price_low_to_high(setup):
    driver = setup
    inventory = InventoryPage(driver)

    inventory.select_sort("lohi")

    prices = inventory.get_product_prices()

    assert prices == sorted(prices)
