import pytest
from utils.credentials import VALID_USERNAME, VALID_PASSWORD
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage

@pytest.fixture
def setup(driver):
    login = LoginPage(driver)
    login.login(VALID_USERNAME, VALID_PASSWORD)
    return driver


def test_add_product_to_cart(setup):
    driver = setup

    inventory = InventoryPage(driver)
    cart = CartPage(driver)

    # Thêm sản phẩm
    inventory.add_to_cart("sauce-labs-backpack")

    # Biểu tượng giỏ hàng phải = 1
    assert inventory.cart_count() == 1

    # Mở trang cart
    cart.open()
    assert cart.get_item_count() == 1


def test_remove_product_from_cart(setup):
    driver = setup

    inventory = InventoryPage(driver)
    cart = CartPage(driver)

    # Thêm 1 sản phẩm trước
    inventory.add_to_cart("sauce-labs-bike-light")
    assert inventory.cart_count() == 1

    # Xóa trong trang cart
    cart.open()
    cart.remove("sauce-labs-bike-light")

    # Cart phải trống
    assert inventory.cart_count() == 0


def test_remove_from_inventory_page(setup):
    driver = setup

    inventory = InventoryPage(driver)

    # Thêm sản phẩm
    inventory.add_to_cart("sauce-labs-bolt-t-shirt")
    assert inventory.cart_count() == 1

    # Remove ngay tại trang inventory
    inventory.remove_from_cart("sauce-labs-bolt-t-shirt")
    assert inventory.cart_count() == 0
