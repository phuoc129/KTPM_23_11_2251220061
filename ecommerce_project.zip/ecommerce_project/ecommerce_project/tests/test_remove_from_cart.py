import pytest
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from utils.credentials import valid_user


@pytest.mark.usefixtures("setup")
class TestRemoveFromCart:
    @pytest.fixture(autouse=True)
    def inject_driver(self, setup):
            self.driver = setup
    def test_remove_in_cart_page(self):
        login = LoginPage(self.driver)
        inventory = InventoryPage(self.driver)
        cart = CartPage(self.driver)

        login.login(valid_user["username"], valid_user["password"])

        inventory.add_first_product()
        inventory.go_to_cart()

        inventory.remove_first_product_cart()
        assert inventory.get_cart_items_count() == 0

    def test_remove_from_inventory_page(self):
        login = LoginPage(self.driver)
        inventory = InventoryPage(self.driver)

        login.login(valid_user["username"], valid_user["password"])

        inventory.add_first_product()
        assert inventory.get_cart_badge_count() == "1"

        inventory.remove_first_product_inventory()
        assert inventory.get_cart_badge_count() == ""
