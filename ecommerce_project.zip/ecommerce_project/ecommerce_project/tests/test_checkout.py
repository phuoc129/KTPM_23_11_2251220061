import pytest
from utils.credentials import VALID_USERNAME, VALID_PASSWORD
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage

@pytest.fixture
def setup(driver):
    login = LoginPage(driver)
    login.login(VALID_USERNAME, VALID_PASSWORD)
    return driver


def test_checkout_success(setup):
    driver = setup

    inventory = InventoryPage(driver)
    cart = CartPage(driver)
    checkout = CheckoutPage(driver)

    inventory.add_to_cart("sauce-labs-backpack")
    cart.open()

    checkout.start_checkout()
    checkout.fill_info("John", "Doe", "12345")
    checkout.finish()

    assert checkout.success_message() == "THANK YOU FOR YOUR ORDER"


def test_checkout_missing_info(setup):
    driver = setup

    inventory = InventoryPage(driver)
    cart = CartPage(driver)
    checkout = CheckoutPage(driver)

    inventory.add_to_cart("sauce-labs-bike-light")
    cart.open()

    checkout.start_checkout()

    # Bỏ trống thông tin cố tình
    checkout.fill_info("", "", "")

    # Phải có thông báo lỗi
    assert "Error" in checkout.get_error_message()
