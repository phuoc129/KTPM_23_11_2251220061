VALID_USERNAME = "standard_user"
VALID_PASSWORD = "secret_sauce"

INVALID_USERNAME = "abcxyz"
INVALID_PASSWORD = "123456"

valid_user = {
    "username": VALID_USERNAME,
    "password": VALID_PASSWORD
}